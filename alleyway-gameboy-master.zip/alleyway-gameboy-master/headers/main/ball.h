#ifndef BALL_HEADER
#define BALL_HEADER set
uint8_t UpdateBall(uint8_t lastSprite);
void ResetBall();

#endif