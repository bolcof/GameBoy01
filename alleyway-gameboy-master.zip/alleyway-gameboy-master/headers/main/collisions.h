#ifndef COLLISIONS_HEADER 
#define COLLISIONS_HEADER set


void BounceAgainstTheWalls();
void CollidePaddleAgainstBall();
void CollideBricksAgainstBall();

#endif