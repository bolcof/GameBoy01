#ifndef PADDLE_HEADER
#define PADDLE_HEADER set

#include <gb/gb.h>

uint8_t UpdatePaddle();
void ResetPaddle();



#endif